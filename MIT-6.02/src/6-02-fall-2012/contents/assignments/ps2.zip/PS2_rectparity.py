# template for 6.02 rectangular parity decoding using error triangulation
import PS2_tests
import numpy

def rect_parity(codeword,nrows,ncols): 
    ## YOUR CODE HERE
    ## return the corrected data
    return

if __name__ == '__main__':
    PS2_tests.test_correct_errors(rect_parity)
